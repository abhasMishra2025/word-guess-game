"use client"

import WordGame from "../word-guess-game"

export default function SyntheticV0PageForDeployment() {
  return <WordGame />
}